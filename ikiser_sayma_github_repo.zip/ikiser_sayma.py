import tkinter as tk
from tkinter import messagebox
import sys
import subprocess
import platform

def speak(text: str):
    try:
        if platform.system() == "Windows":
            ps_command = [
                "powershell",
                "-Command",
                "Add-Type -AssemblyName System.Speech; "
                "$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                f"$speak.Speak('{text}')"
            ]
            subprocess.Popen(ps_command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

class IkiserSaymaApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("İkişer Ritmik Sayma – Erişilebilir Uygulama")
        self.root.geometry("560x520")
        self.root.configure(bg="#f3f6ff")

        self.start_number = 0
        self.step = 2
        self.max_number = 100

        self.expected = self.start_number + self.step
        self.correct_count = 0
        self.total_targets = ((self.max_number - self.start_number) // self.step)

        self.build_ui()
        self.populate_list()
        self.listbox.focus_set()
        self.announce_welcome()

    def announce_welcome(self):
        speak("İkişer ritmik sayma başlıyor. Aşağı ve yukarı oklarla gez. Enter veya boşluk ile seç. İlk doğru sayı iki.")

    def build_ui(self):
        self.title_label = tk.Label(
            self.root, text="İkişer Ritmik Sayma", font=("Segoe UI", 18, "bold"), bg="#f3f6ff", fg="#1f3b77"
        )
        self.title_label.pack(pady=(16, 4))

        self.info_label = tk.Label(
            self.root,
            text=("Yukarı/Aşağı oklarla gezin. Enter veya Boşluk ile seçin.\n"
                  "Amaç: 0'dan başlayarak ikişer artan doğru sayıları bulmak."),
            font=("Segoe UI", 11), bg="#f3f6ff", fg="#223"
        )
        self.info_label.pack(pady=(0, 8))

        self.progress_var = tk.StringVar()
        self.progress_var.set(self.progress_text())
        self.progress_label = tk.Label(self.root, textvariable=self.progress_var,
                                       font=("Segoe UI", 11, "bold"), bg="#f3f6ff", fg="#0b5")
        self.progress_label.pack(pady=(0, 8))

        frame = tk.Frame(self.root, bg="#f3f6ff")
        frame.pack(fill="both", expand=True, padx=16, pady=8)

        self.listbox = tk.Listbox(
            frame,
            activestyle='dotbox',
            selectmode=tk.SINGLE,
            font=("Segoe UI", 14),
            height=14,
        )
        self.listbox.pack(fill="both", expand=True)

        self.root.bind("<Return>", self.on_confirm)
        self.root.bind("<space>", self.on_confirm)
        self.listbox.bind("<Button-1>", lambda e: "break")

        bottom = tk.Frame(self.root, bg="#f3f6ff")
        bottom.pack(pady=(6, 12))

        self.restart_btn = tk.Button(bottom, text="Yeniden Başlat", command=self.restart, font=("Segoe UI", 11))
        self.restart_btn.grid(row=0, column=0, padx=6)

        self.quit_btn = tk.Button(bottom, text="Kapat", command=self.root.destroy, font=("Segoe UI", 11))
        self.quit_btn.grid(row=0, column=1, padx=6)

        self.listbox.selection_clear(0, tk.END)
        self.listbox.selection_set(0)
        self.listbox.see(0)

    def populate_list(self):
        self.listbox.delete(0, tk.END)
        for n in range(0, self.max_number + 1):
            self.listbox.insert(tk.END, f"{n}")

    def progress_text(self):
        return f"İlerleme: {self.correct_count}/{self.total_targets} | Sıradaki doğru: {self.expected}"

    def on_confirm(self, event=None):
        try:
            idx = self.listbox.curselection()[0]
        except IndexError:
            return
        raw = self.listbox.get(idx)
        try:
            value = int(raw.split()[0].replace('✔','').strip())
        except Exception:
            # if line is like "✔ 2 (Doğru)"
            parts = [p for p in raw if p.isdigit()]
            value = int(''.join(parts)) if parts else 0

        if value == self.expected:
            self.correct_count += 1
            self.listbox.delete(idx)
            self.listbox.insert(idx, f"✔ {value} (Doğru)")
            self.listbox.itemconfig(idx, foreground="#0b5")
            speak("Doğru")

            self.expected += self.step
            if self.expected > self.max_number:
                speak("Tebrikler. Görev tamamlandı.")
                messagebox.showinfo("Bitti", "Tebrikler! İkişer ritmik saymayı tamamladınız.")
            self.progress_var.set(self.progress_text())
            next_index = min(idx + 1, self.listbox.size() - 1)
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(next_index)
            self.listbox.see(next_index)
        else:
            self.flash_row(idx)
            speak("Yanlış")
            self.progress_var.set(self.progress_text())

    def flash_row(self, idx, times=2):
        original_fg = self.listbox.itemcget(idx, 'fg')
        def blink(count):
            if count == 0:
                self.listbox.itemconfig(idx, foreground=original_fg)
                return
            self.listbox.itemconfig(idx, foreground="#d22")
            self.root.after(130, lambda: restore(count))
        def restore(count):
            self.listbox.itemconfig(idx, foreground=original_fg)
            self.root.after(130, lambda: blink(count - 1))
        blink(times)

    def restart(self):
        self.expected = self.start_number + self.step
        self.correct_count = 0
        self.populate_list()
        self.progress_var.set(self.progress_text())
        speak("Yeniden başlatıldı. İlk doğru sayı iki.")
        self.listbox.selection_clear(0, tk.END)
        self.listbox.selection_set(0)
        self.listbox.see(0)

def main():
    root = tk.Tk()
    app = IkiserSaymaApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
