
# İkişer Ritmik Sayma — GitHub Actions ile EXE (Bilgisayarına Python Kurmadan)

## Kısa Özet
- Bu repo dosyalarını bir GitHub deposuna yükleyip **Actions → Run workflow** dersen, Windows üzerinde bulutta derlenir.
- Derleme bitince **Artifacts** bölümünden **ikiser_sayma.exe** dosyasını indirirsin.
- Böylece **kendi bilgisayarına Python kurmadan** hazır EXE elde etmiş olursun.

## Adımlar
1. GitHub hesabın yoksa aç.
2. GitHub'da **New Repository** → ad: `ikiser-sayma` (özel/özel fark etmez) → oluştur.
3. Bu klasördeki dosyaları **Upload files** ile depoya yükle:
   - `ikiser_sayma.py`
   - `.github/workflows/build.yml`
4. Repo sayfasında üstte **Actions** sekmesine gir.
   - Sağ üstte **Enable workflows** / **I understand... Enable** gibi bir onay çıkarsa onayla.
   - Solda **Build EXE** iş akışını görürsün. **Run workflow** butonuna bas.
5. Koşum bitince (yeşil tik) o koşuma gir → en alta **Artifacts** bölümünde **ikiser_sayma-exe** var. Ona tıklayıp indir.
6. İndirilen ZIP'in içindeki `ikiser_sayma.exe`'yi çalıştır.

## Klavye ile Kullanım
- **Yukarı/Aşağı oklar**: Listede dolaş
- **Enter / Boşluk**: Seçimi onayla
- Doğru: Sesli "**Doğru**", yanlış: Sesli "**Yanlış**"

İyi eğlenceler!
